# Notes
- Keep VM sizes small (B-series) to minimize cost.
- Consider Azure Bastion for secure access instead of public RDP/SSH.
- Clean up public IPs when pausing labs.
