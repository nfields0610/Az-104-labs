# Lab 21 – Azure Virtual Machines: Deployment, Management & Automation

**Purpose:** Deploy one Windows and one Linux VM, secure with NSGs, configure shared storage, apply tags, and enable automation.  
**Region:** Central US · **Resource Group:** `vm-lab-rg` · **Tags:** `Environment=Lab21`, `CostControl=True`

---

## Screenshot Checkpoints (save into `screenshots/`)

1. `01-ResourceGroup.png` – Resource group overview (name, region, tags)
2. `02-WindowsVM.png` – `winlabvm01` overview after deployment (private IP visible)
3. `03-LinuxVM.png` – `linlabvm01` overview after deployment
4. `04-NSG.png` – NSG **Inbound security rules** table (RDP 3389, SSH 22)
5. `05-FileShare.png` – Azure File Share properties (`labfileshare`) + access key blade
6. `06-Mount.png` – Proof of mounted share (Windows Explorer drive / Linux terminal output)
7. `07-Tags.png` – Resource group **Tags** blade with `Environment=Lab21` and `CostControl=True`
8. `08-AutoShutdown.png` – VM **Auto‑shutdown** settings (8:00 PM CST / 02:00 UTC)
9. `09-CLI-Commands.png` – Terminal showing CLI outputs (you can combine multiple commands per shot)

---

## Steps

### 1) Create Resource Group
**Portal:** Resource groups → + Create → `vm-lab-rg` (Central US) → Add tags.  
**CLI:**
```bash
az group create --name vm-lab-rg --location centralus
az tag create --resource-id $(az group show -n vm-lab-rg --query id -o tsv) --tags Environment=Lab21 CostControl=True
```
📸 Take `01-ResourceGroup.png`

---

### 2) Deploy Windows VM (`winlabvm01`)
**Portal:** Virtual machines → + Create → Azure VM → Windows Server 2022 Datacenter (Gen2) → Size: B1s/B2s → Auto‑shutdown Off (will set later).  
**CLI:**
```bash
az vm create   --resource-group vm-lab-rg   --name winlabvm01   --image "MicrosoftWindowsServer:WindowsServer:2022-datacenter-azure-edition:latest"   --admin-username azureuser   --admin-password "<StrongPasswordHere!>"   --size Standard_B2s   --public-ip-sku Standard
```
> If you prefer SSH keys for Windows (less common), adjust parameters accordingly.
📸 Take `02-WindowsVM.png`

---

### 3) Deploy Linux VM (`linlabvm01`)
**Portal:** Same flow, choose *Ubuntu 22.04 LTS*.  
**CLI:**
```bash
az vm create   --resource-group vm-lab-rg   --name linlabvm01   --image "Canonical:0001-com-ubuntu-server-jammy:22_04-lts:latest"   --admin-username azureuser   --generate-ssh-keys   --size Standard_B1ms   --public-ip-sku Standard
```
📸 Take `03-LinuxVM.png`

---

### 4) Configure NSGs
**Goal:** Allow RDP (3389) to Windows VM and SSH (22) to Linux VM.

**Portal:** Go to each VM’s Networking → *Network security group* → Inbound rules.  
**CLI:**
```bash
# Allow RDP to winlabvm01 NSG
az network nsg rule create   --resource-group vm-lab-rg   --nsg-name $(az network nic show -g vm-lab-rg -n $(az vm show -g vm-lab-rg -n winlabvm01 --query 'networkProfile.networkInterfaces[0].id' -o tsv | xargs basename) --query 'networkSecurityGroup.id' -o tsv | xargs basename)   --name allow-rdp-3389   --priority 2000   --access Allow --direction Inbound --protocol Tcp --destination-port-ranges 3389

# Allow SSH to linlabvm01 NSG
az network nsg rule create   --resource-group vm-lab-rg   --nsg-name $(az network nic show -g vm-lab-rg -n $(az vm show -g vm-lab-rg -n linlabvm01 --query 'networkProfile.networkInterfaces[0].id' -o tsv | xargs basename) --query 'networkSecurityGroup.id' -o tsv | xargs basename)   --name allow-ssh-22   --priority 2001   --access Allow --direction Inbound --protocol Tcp --destination-port-ranges 22
```
📸 Take `04-NSG.png`

> **Security Note:** For real-world deployments, restrict source IP ranges and consider Azure Bastion instead of opening RDP/SSH publicly.

---

### 5) Shared Storage (Azure Files)
**Portal:** Storage accounts → + Create → `stlab21<unique>` → File shares → `labfileshare`.  
**CLI:**
```bash
SA_NAME=stlab21$RANDOM
az storage account create -g vm-lab-rg -n $SA_NAME -l centralus --sku Standard_LRS --kind StorageV2
az storage share-rm create -g vm-lab-rg --storage-account $SA_NAME --name labfileshare --quota 10
```
📸 Take `05-FileShare.png`

**Mount – Windows (inside winlabvm01):**
```powershell
$acct = "<SA_NAME>"
$share = "labfileshare"
$pwd   = (Get-AzStorageAccountKey -ResourceGroupName "vm-lab-rg" -Name $acct)[0].Value
New-PSDrive -Name Z -PSProvider FileSystem -Root "\\$acct.file.core.windows.net\$share" -Credential (New-Object System.Management.Automation.PSCredential("$acct",$([SecureString]$pwd))) -Persist
```
**Mount – Linux (inside linlabvm01):**
```bash
sudo apt update && sudo apt install cifs-utils -y
sudo mkdir -p /mnt/labfiles
sudo mount -t cifs //<SA_NAME>.file.core.windows.net/labfileshare /mnt/labfiles -o vers=3.0,username=<SA_NAME>,password=<storage-key>,dir_mode=0777,file_mode=0777,serverino
```
📸 Take `06-Mount.png`

---

### 6) Tagging
**Portal:** Resource Group → Tags → add `Environment=Lab21`, `CostControl=True`.  
**CLI:**
```bash
az resource tag --tags Environment=Lab21 CostControl=True --resource-group vm-lab-rg
```
📸 Take `07-Tags.png`

---

### 7) Automation
- **Auto‑shutdown:** set to **20:00 (CST)** → 02:00 UTC.
- **Optional Start/Stop:** Use Automation Account or Logic App for daily start/stop.

**CLI (auto‑shutdown once VMs exist):**
```bash
az vm auto-shutdown --resource-group vm-lab-rg --name winlabvm01 --time 2000 --timezone "Central Standard Time" --email Nichelle.s.fields@gmail.com
az vm auto-shutdown --resource-group vm-lab-rg --name linlabvm01 --time 2000 --timezone "Central Standard Time" --email Nichelle.s.fields@gmail.com
``]
📸 Take `08-AutoShutdown.png`

---

### 8) CLI Practice
Run and capture outputs:
```bash
az vm list -o table
az vm stop -g vm-lab-rg -n winlabvm01
az vm deallocate -g vm-lab-rg -n linlabvm01
az resource tag --tags Environment=Lab21 CostControl=True --resource-group vm-lab-rg
```
📸 Take `09-CLI-Commands.png`

---

## Mobile App Capability
| Task | Mobile |
|---|---|
| View RG & Tags | ✅ |
| View VMs | ✅ |
| Create VMs | ⚠️ (limited) |
| Edit NSG rules | ⚠️ (view/limited) |
| Azure Files management | ❌ |
| Toggle Auto‑shutdown | ⚠️ |
