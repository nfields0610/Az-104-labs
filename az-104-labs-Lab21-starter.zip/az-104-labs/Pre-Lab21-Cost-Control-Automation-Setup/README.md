# Pre‑Lab 21 – Cost Control & Automation Setup

**Goal:** Protect Pay‑As‑You‑Go with budgets, alerts, and automation.  
**Status:** ✅ Completed items can be checked off below.

## Checklist
- [x] Create $10 monthly budget (50/80/100% thresholds)
- [x] Add email recipients to budget
- [x] Create `CostAlertGroup` (email + push)
- [x] Create Actual Cost alert rule (`> $8`) via CLI
- [x] Create Service Health alert (Central US) using `CostAlertGroup`
- [ ] Configure VM Auto‑Shutdown (8 PM CST) **(complete in Lab 21 when VMs exist)**

## CLI Snippets
```bash
# Subscription ID
az account show --query id -o tsv

# List action groups
az monitor action-group list -o table

# Create Actual Cost alert rule (subscription scope)
az monitor metrics alert create   --name "MonthlyCostPushAlert"   --resource-group LabNN   --description "Notify by email/push when actual cost exceeds $8"   --condition "avg UsageAndBilling_ActualCost > 8"   --action CostAlertGroup   --severity 4   --scopes /subscriptions/<your-subscription-id>   --target-resource-type "Microsoft.Billing/billingAccounts"   --target-resource-region "global"
```
